/*
 *
 * IBM Confidential
 *
 * 5724-U18, 5737-M66
 * 
 * (C) COPYRIGHT IBM CORPORATION 2001,2021
 *
 * The source code for this program is not published or otherwise
 * divested of its trade secrets, irrespective of what has been
 * deposited with the U.S. Copyright Office.
 *
 */
package psdi.app.bim.viewer.lmv;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.URISyntaxException;
import java.rmi.RemoteException;
import java.security.GeneralSecurityException;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import javax.jws.WebMethod;

import com.ibm.json.java.JSONObject;
import com.ibm.tivoli.maximo.oslc.provider.OslcRequest;

import psdi.app.bim.Constants;
import psdi.app.bim.loader.Factory;
import psdi.app.bim.project.BIMCommission;
import psdi.app.bim.project.BIMOmniClassImport;
import psdi.app.bim.project.BIMSession;
import psdi.app.bim.project.BIMSessionRemote;
import psdi.app.bim.project.BIMUpload;
import psdi.app.bim.project.BIMUploadSet;
import psdi.app.bim.viewer.BuildingModel;
import psdi.app.bim.viewer.dataapi.DataRESTAPI;
import psdi.app.bim.viewer.dataapi.FileReference;
import psdi.app.bim.viewer.dataapi.Result;
import psdi.app.bim.viewer.dataapi.ResultAuthentication;
import psdi.app.bim.viewer.dataapi.ResultBucketDetail;
import psdi.app.bim.viewer.dataapi.ResultBucketList;
import psdi.app.bim.viewer.dataapi.ResultCreateBucket;
import psdi.app.bim.viewer.dataapi.ResultObjectDetail;
import psdi.app.bim.viewer.dataapi.ResultObjectList;
import psdi.app.bim.viewer.dataapi.ResultViewerService;
import psdi.app.bim.viewer.dataapi.UploadProgress;
import psdi.app.bim.viewer.lmv.util.MarkupUtils;
import psdi.mbo.Mbo;
import psdi.mbo.MboRemote;
import psdi.mbo.MboSetRemote;
import psdi.mbo.SqlFormat;
import psdi.security.ConnectionKey;
import psdi.security.UserInfo;
import psdi.server.AppService;
import psdi.server.MXServer;
import psdi.server.event.EventTopicTree;
import psdi.util.MXApplicationException;
import psdi.util.MXException;

public class LMVService extends AppService implements LMVServiceRemote
{

    @SuppressWarnings("unused")
	private static final long serialVersionUID = -2290784028775891027L;
    
    public final static String VER = "v1";
    
    public final static String SERVICE_NAME = "BIMLMV";
    
    public final static String LMV_KEY          = "bim.viewer.LMV.key"; 
    public final static String LMV_SECRET       = "bim.viewer.LMV.secret";
    public final static String LMV_HOST         = "bim.viewer.LMV.host";
    public final static String LMV_VERSION      = "bim.viewer.LMV.api.version";
    public final static String LMV_UPLOAD_LIMIT = "bim.viewer.LMV.model.maxuploadsize";
    
    public final static String BUCKET_POLICY_TRANSIENT  = "transient";
	public final static String BUCKET_POLICY_TEMPORARY  = "temporary";
	public final static String BUCKET_POLICY_PERSISTENT = "persistent";
	
	private DataRESTAPI _restAPI  = null;
	private MXServer    _mxServer = null;
	
	public  static final String PROP_NAME_BIM_MODEL_DIR     = "bim.model.dir";
	public  static final String PROP_NAME_BIM_WORKING_DIR   = "bim.import.dir";
	public  static final String PROP_NAME_BIM_DOC_DIR       = "bim.import.docdir";
	public  static final String PROP_NAME_BIM_MODEL_HOST    = "bim.model.hostname";
	public  static final String PROP_NAME_ACTIVE_VIEWER     = "bim.viewer.active";
	
	
    public static final String DOMAIN_COBIESHEETTYPE = "COBIESHEETTYPE";
    public static final String IMPORT_SCR_EXCEL      = "EXCEL";
    public static final String IMPORT_SCR_CONTACT    = "CONTACT";
    public static final String IMPORT_SCR_FACILITY   = "FACILITY";
    public static final String IMPORT_SCR_FLOOR      = "FLOOR";
    public static final String IMPORT_SCR_SPACE      = "SPACE";
    public static final String IMPORT_SCR_ATTRIBUTE  = "ATTRIBUTE";
    public static final String IMPORT_SCR_COMPONENT  = "COMPONENT";
    public static final String IMPORT_SCR_TYPE       = "TYPE";
    public static final String IMPORT_SCR_SYSTEM     = "SYSTEM";
    public static final String IMPORT_SCR_ZONE       = "ZONE";
    
	public final static int    VERSION_UNKNOWN         = -1;
	public final static int    VERSION_LESS_THAN_7116  = 0;
	public final static int    VERSION_7116_OR_GREATER = 1;
	public final static int    VERSION_75_OR_GREATER   = 2;
	
	private Factory _factory = null;
	
	private static final String QUERY_SESSION = BIMSession.FIELD_BIMSESSIONID + "=:1" 
	                                            + " AND " + BIMSession.FIELD_BIMPROJECTID 
	                                            + "=:2 AND " + BIMSession.FIELD_SITEID + "=:3";
	private static final String QUERY_CLASSIFICATION = BIMOmniClassImport.FIELD_BIMOMNICLASSIMPORTID  + "=:1" ;
	private static final String QUERY_COMMISSION     = BIMCommission.FIELD_BIMPROJECTID + "=:1"   
	                                                   + " AND " + BIMCommission.FIELD_BIMCOMMISSIONID  + "=:2" ;

	public LMVService(
	    MXServer mxServer
    )
	    throws RemoteException
	{
		super(mxServer);
	}

	public LMVService()
	    throws RemoteException
	{
		super();
	}
	
	@Override
    public void init()
	{
		super.init();
		EventTopicTree evt = MXServer.getEventTopicTree();
		try
		{
			BuildingModelEventListener svlistener = new BuildingModelEventListener();
			evt.register( "maximo." + BuildingModel.TABLE_NAME.toLowerCase() + ".delete", svlistener, true );
			WOTrackEventListener wvlistener = new WOTrackEventListener();
			evt.register( "maximo.workorder.delete", wvlistener, true );
			
//	    	BIMServiceRemote bsr = (BIMServiceRemote) MXServer.getMXServer().lookup( BIMService.SERVICE_NAME );
//	    	bsr.setFactory( new ExtCOBie24Factory() );
		}
		catch( MXException e )
		{
			e.printStackTrace();
		}
//        catch( RemoteException e )
//        {
//	        e.printStackTrace();
//        }
	}
    
    @Override
	public Factory getLoaderFactory()
	{
    	return _factory;
	}
    
    @Override
	public void setFactory( 
		Factory factory 
	) {
    	_factory = factory;
    }


    
    @Override
    public int getMaximoVersion() throws RemoteException
    {
    	MXServer server = MXServer.getMXServer();
		
		int mxVersion  = VERSION_LESS_THAN_7116;
		String version = server.getMaxupgValue();
		if( version.compareTo( "V7116" ) >= 0 )
		{
			mxVersion = VERSION_7116_OR_GREATER;
		}
		if( version.compareTo( "V75" ) >= 0 )
		{
			mxVersion = VERSION_75_OR_GREATER;
		}
		return mxVersion;
    }
	
	/**
	 * returns BIMProject Mbo based on the unique key passed
	 * 
	 * @param userInfo
	 * @param key
	 * @return
	 * @throws MXException
	 * @throws RemoteException
	 */
	@Override
    public MboRemote getProject(
	    UserInfo userInfo,
	    String   attribute,
	    long     key 
    ) 
		throws MXException, RemoteException
	{
		SqlFormat sqf=new SqlFormat(userInfo,attribute + "=:1");
		sqf.setObject(1,"BIMPROJECT",attribute, "" + key );
		MboSetRemote projectSet = getMboSet("BIMPROJECT", userInfo);
		projectSet.setWhere(sqf.format());
		projectSet.reset();
		MboRemote mbo = projectSet.getMbo(0);
		projectSet.cleanup();
		return mbo;
	}//getProject()

	@Override
    public void makeDir(
	    File newDir 
    ) 
		throws MXException, RemoteException
	{

		if( newDir == null )
		{
			throw new MXApplicationException( Constants.BUNDLE_MSG, Constants.ERR_NULL_DIRECTORY_NAME );
		}
		String params[] = { newDir.getName() };

		if( newDir.exists() )
		{
			if( newDir.isFile() )
			{
				throw new MXApplicationException( Constants.BUNDLE_MSG, Constants.ERR_FILE_INSTEAD_DIRECTORY, params );
			}
		}
		else
		{
			if( !newDir.mkdirs() )
			{
				throw new MXApplicationException( Constants.BUNDLE_MSG, Constants.ERR_CREATE_DIRECTORY_FAILED, params );
			}
		}
	}
		
	public void copyFile(
	    InputStream is,
	    String      targetDir,
	    String      fileName 
    ) 
    	throws MXException 
	{
		byte buf[] = new byte[0x10000];
		long bytesRead = 0;
		OutputStream os = null;

		try
		{
			makeDir( new File( targetDir ) );
			os = new FileOutputStream( targetDir + "/" + fileName );
			while( bytesRead >= 0 )
			{
				bytesRead = is.read( buf );
				if( bytesRead > 0 )
				{
					os.write( buf, 0, (int)bytesRead );
				}
			}
		}
		catch( IOException ioe )
		{
			throw new MXApplicationException( Constants.BUNDLE_MSG, ioe.getLocalizedMessage() );
		}
		finally
		{
			if( is != null )
			{
				try
				{
					is.close();
				}
				catch( Exception e )
				{ /* ignore */
				}
			}
			if( os != null )
			{
				try
				{
					os.close();
				}
				catch( Exception e )
				{ /* ignore */	}
			}
		}
	}

	@Override
	@WebMethod
	public void uploadClassification(
		OslcRequest request
	) 
		throws MXException, IOException 
	{
		UserInfo userInfo = request.getUserInfo();
		
		String importId     = "";
		String fileName     = "";
		String baseFileName = "";
		
		Map<String,String[]> quryParams = request.getQueryParams();
		String[] values = quryParams.get( "~importId" );
		if( values != null && values.length == 1 )
		{
			importId = values[0];
		}
		values = quryParams.get( "~fileName" );
		if( values != null && values.length == 1 )
		{
			fileName = values[0];
			fileName = fileName.replaceAll( "%26", "&" );
			if( fileName != null && fileName.length() > 0 )
			{
				baseFileName = fileName;
				int idx = baseFileName.lastIndexOf( "\\" );
				if( idx >= 0 )
				{
					baseFileName = baseFileName.substring( idx + 1 );
				}
				idx = baseFileName.lastIndexOf( "/" );
				if( idx >= 0 )
				{
					baseFileName = baseFileName.substring( idx + 1 );
				}
			}
		}
		
		InputStream is;
		try 
		{
			is = request.getInputStream();
		} 
		catch( IOException ioe ) 
		{
			throw new MXApplicationException( Constants.BUNDLE_MSG, "No imput stream" );
		}

		MXServer server = MXServer.getMXServer();
		MboSetRemote classSet = server.getMboSet( BIMOmniClassImport.TABLE_NAME, userInfo );
		SqlFormat sqlf = new SqlFormat( QUERY_CLASSIFICATION );
		sqlf.setObject( 1, BIMOmniClassImport.TABLE_NAME, BIMOmniClassImport.FIELD_BIMOMNICLASSIMPORTID, importId );
		classSet.setWhere(sqlf.format() );
		classSet.reset();
		if( classSet.isEmpty() )
		{
			String params[] = { "", importId };
			throw new MXApplicationException( Constants.BUNDLE_MSG, Constants.ERR_SESSION_NOT_FOUND, params );
		}
		BIMOmniClassImport classMbo = (BIMOmniClassImport)classSet.getMbo( 0 );
		if( !classMbo.isStatusNew() )
		{
			throw new MXApplicationException( Constants.BUNDLE_MSG, Constants.ERR_ALREADY_IMPORTED );
		}
		
		String dirPath = classMbo.getDirectoryPath();
		String localFileName = dirPath + "/" + baseFileName;
		
		classMbo.setValue( BIMOmniClassImport.FIELD_FILENAME, localFileName );
		classMbo.setValue( BIMOmniClassImport.FIELD_SOURCEFILENAME, baseFileName );
		classSet.save();
		
		copyFile( is, dirPath, baseFileName );
	}

	@Override
	@WebMethod
	public void uploadCOBieFile(
		OslcRequest request
	) 
		throws MXException, RemoteException 
	{
		UserInfo userInfo = request.getUserInfo();
		
		String projectId    = "";
		String sessionId    = "";
		String siteId       = "";
		String fileName     = "";
		String baseFileName = "";
		String fileType     = "";
		
		Map<String,String[]> quryParams = request.getQueryParams();
		String[] values = quryParams.get( "~projectId" );
		if( values != null && values.length == 1 )
		{
			projectId = values[0];
		}
		values = quryParams.get( "~sessionId" );
		if( values != null && values.length == 1 )
		{
			sessionId = values[0];
		}
		values = quryParams.get( "~siteId" );
		if( values != null && values.length == 1 )
		{
			siteId = values[0];
		}
		values = quryParams.get( "~fileName" );
		if( values != null && values.length == 1 )
		{
			fileName = values[0];
			fileName = fileName.replaceAll( "%26", "&" );
			if( fileName != null && fileName.length() > 0 )
			{
				baseFileName = fileName;
				int idx = baseFileName.lastIndexOf( "\\" );
				if( idx >= 0 )
				{
					baseFileName = baseFileName.substring( idx + 1 );
				}
				idx = baseFileName.lastIndexOf( "/" );
				if( idx >= 0 )
				{
					baseFileName = baseFileName.substring( idx + 1 );
				}
			}
		}
		values = quryParams.get( "~fileType" );
		if( values != null && values.length == 1 )
		{
			fileType = values[0];
		}

		MXServer server = MXServer.getMXServer();
		MboSetRemote sessionSet = server.getMboSet( BIMSession.TABLE_NAME, userInfo );
		SqlFormat sqlf = new SqlFormat( QUERY_SESSION );
		sqlf.setObject( 1, BIMSession.TABLE_NAME, BIMSession.FIELD_BIMSESSIONID, sessionId );
		sqlf.setObject( 2, BIMSession.TABLE_NAME, BIMSession.FIELD_BIMPROJECTID, projectId );
		sqlf.setObject( 3, BIMSession.TABLE_NAME, BIMSession.FIELD_SITEID, siteId );
		sessionSet.setWhere(sqlf.format() );
		sessionSet.reset();
		if( sessionSet.isEmpty() )
		{
			String params[] = { sessionId, projectId };
			throw new MXApplicationException( Constants.BUNDLE_MSG, Constants.ERR_SESSION_NOT_FOUND, params );
		}
		BIMSessionRemote session = (BIMSessionRemote)sessionSet.getMbo( 0 );
		if( !session.isStatusNew() )
		{
			throw new MXApplicationException( Constants.BUNDLE_MSG, Constants.ERR_ALREADY_IMPORTED );
		}
		
		String uploadDir = session.getUploadDirectory();
		String localFileName = uploadDir + "/" + baseFileName;
				
		InputStream is;
		try 
		{
			is = request.getInputStream();
		} 
		catch( IOException ioe ) 
		{
			throw new MXApplicationException( Constants.BUNDLE_MSG, "No imput stream" );
		}
		
		MboSetRemote fileSet = session.getMboSet( "BIMFILE" );
		MboRemote fileMbo = fileSet.add();
		fileMbo.setValue( BIMUpload.FIELD_SOURCEFILENAME, baseFileName );
		fileMbo.setValue( BIMUpload.FIELD_FILENAME, localFileName );
		fileMbo.setValue( BIMUpload.FIELD_COBIESHEET, "!" + fileType + "!" );
		fileSet.save();
		fileSet.close();
		
		copyFile( is, uploadDir, baseFileName );
	}
	
	@Override
	@WebMethod
	public MboRemote startSession(
		UserInfo userInfo,
		String projectId,
		String sessionId,
		String siteId
	) 
		throws RemoteException, MXException 
	{
		MXServer server = MXServer.getMXServer();
		MboSetRemote sessionSet = server.getMboSet( BIMSession.TABLE_NAME, userInfo );
		SqlFormat sqlf = new SqlFormat( QUERY_SESSION );
		sqlf.setObject( 1, BIMSession.TABLE_NAME, BIMSession.FIELD_BIMSESSIONID, sessionId );
		sqlf.setObject( 2, BIMSession.TABLE_NAME, BIMSession.FIELD_BIMPROJECTID, projectId );
		sqlf.setObject( 3, BIMSession.TABLE_NAME, BIMSession.FIELD_SITEID, siteId );
		sessionSet.setWhere(sqlf.format() );
		sessionSet.reset();
		if( sessionSet.isEmpty() )
		{
			String params[] = { sessionId, projectId };
			throw new MXApplicationException( Constants.BUNDLE_MSG, Constants.ERR_SESSION_NOT_FOUND, params );
		}
		BIMSessionRemote session = (BIMSessionRemote)sessionSet.getMbo( 0 );
		if( !session.isStatusNew() )
		{
			throw new MXApplicationException( Constants.BUNDLE_MSG, Constants.ERR_ALREADY_IMPORTED );
		}
		
		int updateType = -1;
		switch( session.getSessionType() )
		{
			case BIMSession.SESSION_TYPE_VALIDATE:
				updateType = BIMSession.UPDATE_VALIDATE_ONLY;
				break;
			case BIMSession.SESSION_TYPE_IMPORT:
				updateType = BIMSession.UPDATE_INCREMENTAL;
				break;
			case BIMSession.SESSION_TYPE_MERGE:
			case BIMSession.SESSION_TYPE_UPDATE:
				updateType = session.getUpdateBehavior();
				break;
			case BIMSession.SESSION_TYPE_EXPORT:
				break;
		}
		
		if( updateType > 0 )
		{
			BIMUploadSet uploadSet = (BIMUploadSet)session.getMboSet( "BIMFILE" );
			if( uploadSet.isEmpty() )
			{
				throw new MXApplicationException( Constants.BUNDLE_MSG, Constants.ERR_IMPORT_FILE_REQUIRED );
			}
			uploadSet.parseCollection( updateType );
		}
		else
		{
			session.exportToCOBie();
		}
		
		return session;
	}
	
	@Override
	@WebMethod
	public MboRemote startBuildingCommisioning(
		UserInfo userInfo,
		String projectId,
		String commissioningId
	) 
		throws RemoteException, 
		       MXException
    {
		MXServer server = MXServer.getMXServer();
		MboSetRemote commSet = server.getMboSet( BIMCommission.TABLE_NAME, userInfo );
		SqlFormat sqlf = new SqlFormat( QUERY_COMMISSION );
		sqlf.setObject( 1, BIMCommission.TABLE_NAME, BIMCommission.FIELD_BIMPROJECTID, projectId );
		sqlf.setObject( 2, BIMCommission.TABLE_NAME, BIMCommission.FIELD_BIMCOMMISSIONID, commissioningId );
		commSet.setWhere(sqlf.format() );
		commSet.reset();
		if( commSet.isEmpty() )
		{
			String params[] = { commissioningId, projectId };
			throw new MXApplicationException( Constants.BUNDLE_MSG, Constants.ERR_SESSION_NOT_FOUND, params );
		}
		BIMCommission commMbo = (BIMCommission)commSet.getMbo( 0 );
		if( !commMbo.isStatusNew() )
		{
			throw new MXApplicationException( Constants.BUNDLE_MSG, Constants.ERR_ALREADY_IMPORTED );
		}
		
		commMbo.commision();
		
		return commMbo;
    }

	
	@Override
	@WebMethod
	public MboRemote startClassificationImport(
		UserInfo userInfo,
		String importId,
		String fileType
	)
	    throws RemoteException, MXException 
    {
		
		MXServer server = MXServer.getMXServer();
		MboSetRemote classSet = server.getMboSet( BIMOmniClassImport.TABLE_NAME, userInfo );
		SqlFormat sqlf = new SqlFormat( QUERY_CLASSIFICATION );
		sqlf.setObject( 1, BIMOmniClassImport.TABLE_NAME, BIMOmniClassImport.FIELD_BIMOMNICLASSIMPORTID, importId );
		classSet.setWhere(sqlf.format() );
		classSet.reset();
		if( classSet.isEmpty() )
		{
			String params[] = { "", importId };
			throw new MXApplicationException( Constants.BUNDLE_MSG, Constants.ERR_SESSION_NOT_FOUND, params );
		}
		BIMOmniClassImport classMbo = (BIMOmniClassImport)classSet.getMbo( 0 );
		if( !classMbo.isStatusNew() )
		{
			throw new MXApplicationException( Constants.BUNDLE_MSG, Constants.ERR_ALREADY_IMPORTED );
		}
		
		BIMOmniClassImport.LoaderName = fileType;
		
		classMbo.runImport( fileType );

		return classMbo;
	}

	
	public static void deleteDirecotry(
		File file
	) {
		if( !file.isDirectory() )
		{
			file.delete();
			return;
		}
		
 		File files[] = file.listFiles();
 		for( int i = 0; i < files.length; i++ )
 		{
 			if( file.isDirectory() )
 			{
 				deleteDirecotry( files[i] );
 			}
 			files[i].delete();
 		}
	}
	
	/**
	 * Run as part of the service start sequence.  Searches for BIMSession
	 * Mbos in an active state and changes the state to failed.  Sessions
	 * can be left in an active state if the server crashes or is shutdown
	 * while the background thread for the session (Import/validate/export)
	 * is active
	 * 
	 * Note: Currently only works correctly in 7.5.0 or greater
	 * 
	 * @author Doug Wood
	 */
	private class CleanUp implements Runnable
	{
		@Override
        public void run()
		{
			// Cleanup an import sessions left in an IMPORTING state by a system crash 
	    	try
	        {
	    		MXServer server = MXServer.getMXServer();
		        while( !server.isMxserverStarted() )
		        {
					Thread.sleep( 10000 );
		        }
	        }
	        catch( Throwable t )
	        {
		        t.printStackTrace();
	        }
	        cleanUpSessions();
		}
		
		/**
		 * Look for all BIMSession objects that are in one of the active state, "Importing" or
		 * "Validating" and set them to "Failed".  Sessions could be left in one of these states
		 * if the Maximo server crashes or is shutdown while an import or validate thread is running
		 * @return True on success, false on an error
		 */
		private boolean cleanUpSessions()
		{
			Connection    con  = null;
			ConnectionKey sKey = null;
	        try
	        {
	            sKey = MXServer.getMXServer().getDBManager().getSystemConnectionKey();
				con = MXServer.getMXServer().getDBManager().getConnection( sKey );
	
				HashSet<String> statusList = getStatusList( con );
				String failedValue = getFailedValue( con ); 
				// Shouldn't happen implies misconfiugred DB
				if( statusList.size() == 0 || failedValue == null )
				{
					return false;
				}
				int count = updateSessionStatus( con, statusList, failedValue );
	    		System.out.println( "BIMServer cleanup thread " + count + " sessions to fix up status" );
	        }
	        catch( Exception e1 )
	        {
	            e1.printStackTrace();
	            return false;
	        }
	        finally
	        {
				try
				{
					if( con != null )
					{
						MXServer.getMXServer().getDBManager().freeConnection( sKey );
					}
				}
				catch( Exception ex )
				{ /* Ignore */ }
	        }
	        return true;
		}
	
		private String getFailedValue(
	        Connection con
		) {
			
			String sqlString = "select value from synonymdomain where domainid = 'BIMIMPORTSTATUS' and maxvalue = 'FAILED' and defaults = 1";
			Statement s = null;
			ResultSet rs = null;
			String failedString = null;
			try
			{
				if( con != null )
				{
					s = con.createStatement();
					s.execute( new SqlFormat( sqlString ).format() );
					rs = s.getResultSet();
	
					if( rs.next() )
					{
						failedString =  rs.getString( 1 );
					}
				}
			}
			catch( Exception e )
			{
				e.printStackTrace();
			}
			finally
			{
				try
				{
					if( rs != null )
						rs.close();
				}
				catch( Exception ex )
				{ /* Ignore */ }
				try
				{
					if( s != null )
					{
						s.close();
					}
				}
				catch( Exception ex )
				{ /* Ignore */ }
			}
			return failedString;
		}
		
		/**
		 * Get a list of active status for BIMImportStatus domain
		 * @return
		 * @throws MXException
		 */
		private HashSet<String> getStatusList(
	        Connection con
		) {
			HashSet<String> values = new HashSet<String>();
			String sqlString;
	
			sqlString = "select value from synonymdomain where domainid = 'BIMIMPORTSTATUS' and not maxvalue in ( 'NEW', 'COMPLETE', 'FAILED')";
	
			Statement s = null;
			ResultSet rs = null;
			try
			{
				if( con != null )
				{
					s = con.createStatement();
					s.execute( new SqlFormat( sqlString ).format() );
					rs = s.getResultSet();
	
					while( rs.next() )
					{
						values.add( rs.getString( 1 ) );
					}
				}
			}
			catch( Exception e )
			{
				e.printStackTrace();
			}
			finally
			{
				try
				{
					if( rs != null )
					{
						rs.close();
					}
				}
				catch( Exception ex )
				{ /* Ignore */ }
				try
				{
					if( s != null )
					{
						s.close();
					}
				}
				catch( Exception ex )
				{ /* Ignore */ }
			}
			return values;
		}
	
		private int updateSessionStatus(
	        Connection      con,
	        HashSet<String> activeStatus,
	        String          failedStatus
		) {
			int rowCount = -1;
	
			StringBuffer updateStatuement = new StringBuffer( "update " );
			updateStatuement.append( BIMSession.TABLE_NAME );
			updateStatuement.append( " set " );
			updateStatuement.append( BIMSession.FIELD_STATUS );
			updateStatuement.append( " = '" );
			updateStatuement.append( failedStatus );
			updateStatuement.append( "' where "  );
			updateStatuement.append( BIMSession.FIELD_STATUS );
			updateStatuement.append( " IN ( " );
			Iterator<String> itr = activeStatus.iterator();
			while( itr.hasNext() )
			{
				updateStatuement.append( "'" );
				updateStatuement.append( itr.next() );
				updateStatuement.append( "'" );
				if( itr.hasNext() )
				{
					updateStatuement.append( ", " );
				}
			}
			updateStatuement.append( " )" );
			
			Statement s = null;
			try
			{
				if( con != null )
				{
					s = con.createStatement();
					rowCount = s.executeUpdate( new SqlFormat( updateStatuement.toString() ).format() );
				}
			}
			catch( Exception e )
			{
				e.printStackTrace();
			}
			finally
			{
				try
				{
					if( s != null )
					{
						s.close();
					}
				}
				catch( Exception ex )
				{ /* Ignore */ }
			}
			return rowCount;
		}
	}

	@Override
    public ResultAuthentication authenticate(
    	String scope[]
	)
	    throws IOException, 
	           URISyntaxException
	{
		return _restAPI.authenticate( scope );
	}
	
	@Override
    public ResultCreateBucket bucketCreate(
		String bucketKey,
		String policy,
		String region
	) 
	    throws IOException, 
	           URISyntaxException
	{
		return _restAPI.bucketCreate( bucketKey, policy, region );
	}
	
    @Override
    public Result bucketDelete(
    	String bucketKey
	) 
		throws IOException, 
		       URISyntaxException 
    {
		return _restAPI.bucketDelete( bucketKey  );
    }
	
    @Override
    public Result bucketGrantRights(
		String bucketKey,
		String serviceId,
		String access
	) 
	    throws IOException, 
	           URISyntaxException
	{
		return _restAPI.bucketGrantRightsV2( bucketKey, serviceId, access );
	}
	
	@Override
    public ResultBucketList bucketList(
    	String region
	) 
		throws IOException, 
		       URISyntaxException 
    {
		return _restAPI.bucketList( region );
    }
	
	@Override
    public Result bucketRevokeRights(
		String bucketKey,
		String serviceId
	) 
	    throws IOException, 
	           URISyntaxException
	{
		return _restAPI.bucketRevokeRightsV2( bucketKey, serviceId );
	}

	@Override
    public ResultBucketDetail bucketQueryDetails(
		String bucketKey
	) 
	    throws IOException, 
	           URISyntaxException
	{
		return _restAPI.bucketQueryDetails( bucketKey );
	}

	@Override
    public ResultObjectDetail objectQueryDetails(
		String bucketKey,
		String objectKey
	) 
	    throws IOException, 
	           URISyntaxException
	{
		return _restAPI.objectQueryDetails( bucketKey, objectKey );
	}

	@Override
    public Result objectDelete(
		String bucketKey,
		String objectKey
	) 
	    throws IOException, 
	           URISyntaxException
	{
		return _restAPI.objectDelete( bucketKey, objectKey );
	}

	@Override
	public ResultObjectList objectList(
		String bucketKey,
		String objectKeyPrefix
	) 
	    throws IOException, 
	           URISyntaxException
    {
		return _restAPI.objectList( bucketKey, objectKeyPrefix );
    }
	           
	@Override
	public Result viewableDeregister(
		String viewableURN
	) 
		throws IOException, 
		       URISyntaxException
	{
		return _restAPI.viewableDeregister( viewableURN );
	}

	@Override
  	public ResultViewerService viewableQuery(
		String viewableURN
	) 
	    throws IOException, 
	           URISyntaxException
	{
		return _restAPI.viewableQuery( viewableURN );
	}

	@Override
    public Result viewableRegister(
		String  viewableURN,
		String  region,
		boolean compressed,
		String  rootFileName,
		boolean test,
		boolean force
	) 
	    throws IOException, 
	           URISyntaxException
	{
		return _restAPI.viewableRegister( viewableURN, region, compressed, rootFileName, test, force );
	}
	
	@Override
	public void clearAuthCache()
		throws RemoteException 
	{
		_restAPI.clearAuthCache();
	}
	
	@Override
	@WebMethod
	public String getAuthToken() throws IOException, URISyntaxException
	{
		String scope[] = { DataRESTAPI.SCOPE_DATA_READ};
		ResultAuthentication result = _restAPI.authenticate( scope );
		return result.getAuthTokenJSOM();
	}
	
	@Override
	@WebMethod
	public MboSetRemote getSavedViews(
		UserInfo userInfo,
		String   modelId,
		String   siteId
	) 
		throws RemoteException, 
		       MXException 
	{
		MboSetRemote savedViewSet = _mxServer.getMboSet( SavedView.TABLE_NAME, userInfo );
		String query = SavedView.FIELD_BUILDINGMODELID + "=:1 AND " + SavedView.FIELD_SITEID + "=:2 " +
				       "AND ( " + SavedView.FIELD_OWNER + "=:3 OR " + SavedView.FIELD_SHARED + "= 1 )"; 
		SqlFormat sqlf = new SqlFormat( query );
		sqlf.setObject( 1, SavedView.TABLE_NAME, SavedView.FIELD_BUILDINGMODELID, modelId );
		sqlf.setObject( 2, SavedView.TABLE_NAME, SavedView.FIELD_SITEID, siteId );
		sqlf.setObject( 3, SavedView.TABLE_NAME, SavedView.FIELD_OWNER, userInfo.getUserName() );
		savedViewSet.setWhere( sqlf.format() );
		savedViewSet.reset();
		return savedViewSet;
	}

	@Override
	@WebMethod
	public String getAssetLocationMarkups(
			UserInfo userInfo,
			String   modelId,
			String	 assetloc,
			String   siteId,
			Boolean   isAsset
		) 
				throws RemoteException, MXException 
	{

		String bimMarkups = "";
		String ASSET_LOC = isAsset ? "assetnum" : "location";
		String bimMarkupSVGString = "";
		List<String> bimMarkupsList = null;
		JSONObject bimDefectMarkups = new JSONObject();
		
		MboSetRemote savedViewSet = _mxServer.getMboSet( "BIMLMVDEFECTVIEW", userInfo );
		String query = null;

		query = SavedView.FIELD_BUILDINGMODELID + "=:1 AND " + SavedView.FIELD_SITEID + "=:2 "+ " AND " + ASSET_LOC + " = :3"; 
		SqlFormat sqlf = new SqlFormat( query );
		sqlf.setObject( 1, "BIMLMVDEFECTVIEW", SavedView.FIELD_BUILDINGMODELID, modelId );
		sqlf.setObject( 2, "BIMLMVDEFECTVIEW", SavedView.FIELD_SITEID, siteId );
		sqlf.setObject( 3, "BIMLMVDEFECTVIEW", ASSET_LOC, assetloc );

		savedViewSet.setWhere( sqlf.format() );
		savedViewSet.reset();
		bimDefectMarkups = MarkupUtils.generateDefectSvgMboSet(savedViewSet);
		bimMarkupsList = MarkupUtils.generateMarkupSvgMboSet(savedViewSet);
		bimMarkups = MarkupUtils.generateMarkupSvgString(bimMarkupsList);
		bimDefectMarkups.put("markupData", bimMarkups);
		try {
			bimMarkupSVGString = bimDefectMarkups.serialize(true);
		} catch (IOException e) {
			e.printStackTrace();
		}
		return bimMarkupSVGString;
	}

	@Override
	@WebMethod
	public MboRemote linkModel(
		UserInfo userInfo,
		String storageName,
		String modelName,
		String description,
		String orgId,
		String siteId,
		boolean linkViewable
	) 
		throws RemoteException, MXException 
	{
		MboSetRemote modelSet = _mxServer.getMboSet( Model.TABLE_NAME, userInfo );
		
		String userStorageName;
		MXServer server = MXServer.getMXServer();
    	String key       = server.getProperty( LMVService.LMV_KEY );
    	
    	if( storageName.endsWith( key.toLowerCase() ))
    	{
    		userStorageName = storageName.substring( 0, storageName.length() - key.length() );
    	}
    	else
    	{
    		userStorageName = storageName;
    	}
    	
		ModelRemote model = (ModelRemote)modelSet.add();
		model.setValue( Model.FIELD_ORGID,         orgId );
		model.setValue( Model.FIELD_SITEID,        siteId );
		model.setValue( Model.FIELD_BUCKETKEY,     userStorageName );
		model.setValue( Model.FIELD_BUCKETKEYFULL, storageName );
		model.setValue( Model.FIELD_DESCRIPTION,   description );
		model.setValue( Model.FIELD_OBJECTKEY,     modelName );
		model.setValue( Model.FIELD_AUTOLINK,      linkViewable );
		model.attach();
		modelSet.save();
		if( linkViewable )
		{
			model.linkViewable();
		}
		String query = Model.FIELD_SITEID + " = '" + siteId + "' AND " + Model.FIELD_OBJECTKEY + " = '" + modelName.toLowerCase() + "'";
		modelSet.setWhere( query );
		modelSet.reset();
		model = (ModelRemote)modelSet.getMbo( 0 );
		return model;
	}

	@Override
	@WebMethod
	public MboRemote linkStorage(
		UserInfo userInfo,
		String storageName,
		String description,
		String orgId,
		String siteId,
		boolean appendKey
	) 
		throws RemoteException, MXException 
	{
		MboSetRemote bucketSet = _mxServer.getMboSet( Bucket.TABLE_NAME, userInfo );
		BucketRemote bucket = (BucketRemote)bucketSet.add();
		bucket.setValue( Bucket.FIELD_BUCKETKEY,   storageName );
		bucket.setValue( Bucket.FIELD_DESCRIPTION, description );
		bucket.setValue( Bucket.FIELD_ORGID,       orgId );
		bucket.setValue( Bucket.FIELD_SITEID,      siteId );
		bucket.setValue( Bucket.FIELD_ISAPPENDKEY, appendKey );
		bucket.attach();
		String bucketKeyFull = bucket.getString( Bucket.FIELD_BUCKETKEYFULL );
		bucketSet.save();
		bucketSet.setWhere( Bucket.FIELD_BUCKETKEYFULL + " = '" + bucketKeyFull +"'"  );
		bucketSet.reset();
		return bucketSet.getMbo( 0 );
	}

	
	@Override
    public Result linkFileSet(
		FileReference master,
		FileReference children[]
	) 
		    throws IOException, 
	           URISyntaxException
	{
		return _restAPI.linkFileSet( master, children );
	}

	/**
	 * 
	 * @return
	 * @throws GeneralSecurityException 
	 */
	@Override
	public ResultObjectDetail objectUploadChunked(
		String         bucketKey,
		String         objectKey,
		String         fileName,
		UploadProgress tracker
	) 
	    throws URISyntaxException, 
	           GeneralSecurityException, 
	           IOException
    {
		return _restAPI.objectUploadChunked( bucketKey, objectKey, fileName, tracker );
	}
	
	static void testForError(
		Mbo    mbo, 
		Result result
	) 
		throws RemoteException, 
		       MXException 
	{
        if( result.isError() )
        {
        	if( result.getErrorType() == Result.ERROR_TYPE.API )
        	{
        		switch( result.getAPIErrorCode())
        		{
        		case Result.API_ERR_BAD_CHECKSUM:
        			throw new MXApplicationException( Messages.BUNDLE_MSG, Messages.ERR_BAD_CHECKSUM );
        		case Result.API_ERR_NO_OBJECT:
        			throw new MXApplicationException( Messages.BUNDLE_MSG, Messages.ERR_NO_OBJECT );
        		}
        	}
        	String errCode = result.getErrorCode();
        	if( errCode.length() == 0 )
        	{
        		errCode = getHTTPMessageFromCode( mbo, result.getHttpStatus() );
        	}
        	String errMsg = result.getErrorMessage();
        	if( errMsg.length() == 0 )
        	{
        		errMsg = "" + result.getRawError();
        	}
        	String params[] = { errCode, errMsg };
        	if( mbo != null )
        	{
        		try
                {
	                mbo.setValue( Bucket.FIELD_LASTERROR, errCode );
	                mbo.setValue( Bucket.FIELD_LONGLASTERROR, errMsg );
                }
                catch( RemoteException e )
                { /* Igmore */ }
                catch( MXException e )
                { /* Igmore */ }
        	}
			throw new MXApplicationException( Messages.BUNDLE_MSG, Messages.ERR_AUTODESK_API, params );
        }
	}
	
	
	static String getHTTPMessageFromCode(
		MboRemote mbo,
		int       httpStatus
	) 
		throws RemoteException, 
		       MXException 
	{
		String key = "";
		
		switch( httpStatus )
		{
		case 400:
			key = Messages.HTTP_400;
			break;
		case 401: 
			key = Messages.HTTP_401;
			break;
		case 402:
			key = Messages.HTTP_402;
			break;
		case 403:
			key = Messages.HTTP_403;
			break;
		case 404:
			key = Messages.HTTP_404;
			break;
		case 405:
			key = Messages.HTTP_405;
			break;
		case 406:
			key = Messages.HTTP_406;
			break;
		case 407:
			key = Messages.HTTP_407;
			break;
		case 408:
			key = Messages.HTTP_408;
			break;
		case 409:
			key = Messages.HTTP_409;
			break;
		case 410:
			key = Messages.HTTP_401;
			break;
		case 411:
			key = Messages.HTTP_411;
			break;
		case 412:
			key = Messages.HTTP_412;
			break;
		case 413:
			key = Messages.HTTP_413;
			break;
		case 414:
			key = Messages.HTTP_414;
			break;
		case 415:
			key = Messages.HTTP_415;
			break;
		case 416:
			key = Messages.HTTP_416;
			break;
		case 417:
			key = Messages.HTTP_417;
			break;
		case 421:
			key = Messages.HTTP_421;
			break;
		case 422:
			key = Messages.HTTP_422;
			break;
		case 423:
			key = Messages.HTTP_423;
			break;
		case 424:
			key = Messages.HTTP_424;
			break;
		case 426:
			key = Messages.HTTP_426;
			break;
		case 428:
			key = Messages.HTTP_428;
			break;
		case 429:
			key = Messages.HTTP_429;
			break;
		case 431:
			key = Messages.HTTP_431;
			break;
		case 451:
			key = Messages.HTTP_451;
			break;

		case 500:
			key = Messages.HTTP_500;
			break;
		case 501:
			key = Messages.HTTP_501;
			break;
		case 502:
			key = Messages.HTTP_502;
			break;
		case 503:
			key = Messages.HTTP_503;
			break;
		case 504:
			key = Messages.HTTP_504;
			break;
		case 505:
			key = Messages.HTTP_505;
			break;
		case 506:
			key = Messages.HTTP_506;
			break;
		case 507:
			key = Messages.HTTP_507;
			break;
		case 508:
			key = Messages.HTTP_508;
			break;
		case 510:
			key = Messages.HTTP_510;
			break;
		case 511:
			key = Messages.HTTP_511;
			break;
		}

		return mbo.getMessage( Messages.BUNDLE_MSG, key, "" + httpStatus );
	}
}
