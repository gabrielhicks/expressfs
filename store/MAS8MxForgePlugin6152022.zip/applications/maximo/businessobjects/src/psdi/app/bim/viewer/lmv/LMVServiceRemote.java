/*
 *
 * IBM Confidential
 *
 * 5724-U18, 5737-M66
 * 
 * (C) COPYRIGHT IBM CORPORATION 2001,2021
 *
 * The source code for this program is not published or otherwise
 * divested of its trade secrets, irrespective of what has been
 * deposited with the U.S. Copyright Office.
 *
 */
package psdi.app.bim.viewer.lmv;

import java.io.File;
import java.io.IOException;
import java.net.URISyntaxException;
import java.rmi.RemoteException;
import java.security.GeneralSecurityException;

import com.ibm.tivoli.maximo.oslc.provider.OslcRequest;

import psdi.app.bim.loader.Factory;
import psdi.app.bim.viewer.dataapi.FileReference;
import psdi.app.bim.viewer.dataapi.Result;
import psdi.app.bim.viewer.dataapi.ResultAuthentication;
import psdi.app.bim.viewer.dataapi.ResultBucketDetail;
import psdi.app.bim.viewer.dataapi.ResultBucketList;
import psdi.app.bim.viewer.dataapi.ResultCreateBucket;
import psdi.app.bim.viewer.dataapi.ResultObjectDetail;
import psdi.app.bim.viewer.dataapi.ResultObjectList;
import psdi.app.bim.viewer.dataapi.ResultViewerService;
import psdi.app.bim.viewer.dataapi.UploadProgress;
import psdi.mbo.MboRemote;
import psdi.mbo.MboSetRemote;
import psdi.security.UserInfo;
import psdi.server.AppServiceRemote;
import psdi.util.MXException;

public interface LMVServiceRemote extends AppServiceRemote {

    public int getMaximoVersion() throws RemoteException;
	 
	/**@see psdi.app.bim.BIMService#getProject(UserInfo userInfo,String attribute,String key)
	 */
	public MboRemote getProject(UserInfo userInfo,String attribute, long key) throws MXException,RemoteException;
	
	/**@see psdi.app.bim.BIMService#makeDir(File directory)
	 */
	public void makeDir(File directory) throws MXException,RemoteException;
	
	/**
	 * Gets a factory classed used to create most loader classes.  This class may be replaced to extend 
	 * loader features.
	 * A default COBie24 factory is created by the BIM service at initialization
	 * @return Current loader Factory instance
	 */
	public Factory getLoaderFactory() throws RemoteException, MXException;
	
	/**
	 * Update the loader factory.
	 * Should typically only be called during Maximo initialization
	 * @param factory
	 * @throws RemoteException
	 * @throws MXException
	 */
	public void setFactory( Factory factory ) throws RemoteException, MXException;
	
	/**
	 * Web method to start a session via REST
	 * THe session must be ready to run, including having files uploaded and upload records
	 * defined
	 * @param userInfo
	 * @param projectId
	 * @param sessionId
	 * @param siteId
	 * @return JSOM error object
	 * @throws RemoteException
	 * @throws MXException
	 */
	public MboRemote startSession(
		UserInfo userInfo,
		String projectId,
		String sessionId,
		String siteId
	) throws RemoteException, MXException; 
	
	/**
	 * Web method to start an Omniclass or Uniformate import session via REST
	 * THe session must be ready to run, including having files uploaded 
	 * @param userInfo
	 * @param importId
	 * @return JSOM error object
	 * @throws RemoteException
	 * @throws MXException
	 */
	public MboRemote startClassificationImport(
		UserInfo userInfo,
		String importId,
		String fileType
	) throws RemoteException, MXException; 
	
	/**
	 * Web method to start a previously created building commissioning session
	 * @param userInfo
	 * @param projectId
	 * @param commissiingId
	 * @return
	 * @throws RemoteException
	 * @throws MXException
	 */
	public MboRemote startBuildingCommisioning(
		UserInfo userInfo,
		String projectId,
		String commissioningId
	) throws RemoteException, MXException; 

	
	public void uploadClassification(
			OslcRequest request
	) throws MXException, IOException; 
	
	public void uploadCOBieFile(
			OslcRequest request
	) throws MXException, RemoteException; 
	
	
	public ResultAuthentication authenticate( String scope[] )
		    throws IOException, URISyntaxException;

	public ResultCreateBucket bucketCreate(
		String bucketKey,
		String policy,
		String region
	) throws IOException, URISyntaxException;

    public Result bucketDelete(
    	String bucketKey
	) throws IOException, URISyntaxException; 

	public Result bucketGrantRights(
		String bucketKey,
		String serviceId,
		String access
	) throws IOException, URISyntaxException;

    public ResultBucketList bucketList(
    	String region
	) 
		throws IOException, 
		       URISyntaxException; 

	public ResultBucketDetail bucketQueryDetails(
		String bucketKey
	) throws IOException, URISyntaxException;

	public Result bucketRevokeRights(
		String bucketKey,
		String serviceId
	) throws IOException, URISyntaxException;
	
	public String getAuthToken() 
		throws IOException, URISyntaxException;

	public void clearAuthCache() throws RemoteException;

	public MboSetRemote getSavedViews(
		UserInfo userInfo,
		String   modelId,
		String   siteId
	) throws RemoteException, MXException; 

	public String getAssetLocationMarkups (
			UserInfo userInfo,
			String   modelId,
			String	 assetlocid,
			String   siteId,
			Boolean  isAsset
		) throws RemoteException, MXException; 

	public Result linkFileSet(
		FileReference master,
		FileReference children[]
	) throws IOException, URISyntaxException;
	
	public MboRemote linkModel(
        UserInfo userInfo,
        String storageName,
        String modelName,
		String description,
        String orgId,
        String siteId,
        boolean linkViewable ) throws RemoteException, MXException;
	
	public MboRemote linkStorage(
        UserInfo userInfo,
        String storageName,
		String description,
        String origId,
        String siteId,
        boolean appendKey ) throws RemoteException, MXException ;

	public ResultObjectList objectList(
		String bucketKey,
		String objectKeyPrefix
	) throws IOException, URISyntaxException;

	public Result objectDelete(
		String bucketKey,
		String objectKey
	) throws IOException, URISyntaxException;

	public ResultObjectDetail objectQueryDetails(
		String bucketKey,
		String objectKey
	) throws IOException, URISyntaxException;

	public ResultObjectDetail objectUploadChunked(
		String         bucketKey,
		String         objectKey,
		String         fileName,
		UploadProgress tracker
	) throws IOException, URISyntaxException, GeneralSecurityException;

	public Result viewableDeregister(
		String viewableURN
	) throws IOException, URISyntaxException;

	public ResultViewerService viewableQuery(
		String viewableURN
	) throws IOException, URISyntaxException;

	public Result viewableRegister(
		String  viewableURN,
		String  region,
		boolean compressed,
		String  rootFilename,
		boolean test,
		boolean force
	) throws IOException, URISyntaxException;
}
